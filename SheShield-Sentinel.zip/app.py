from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import joblib
import pandas as pd
import numpy as np
import os
import json
from datetime import datetime, timedelta
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///safety_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

safety_model = None
encoders = None

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    emergency_contacts = db.Column(db.Text)  # JSON string
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class EmergencyLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    alert_type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='active')

class RouteHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    source_lat = db.Column(db.Float, nullable=False)
    source_lng = db.Column(db.Float, nullable=False)
    dest_lat = db.Column(db.Float, nullable=False)
    dest_lng = db.Column(db.Float, nullable=False)
    safety_score = db.Column(db.Float, nullable=False)
    risk_level = db.Column(db.String(20), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Safety Score Calculation
def calculate_safety_score(lat, lng, time_of_day='day'):
    """Calculate safety score based on various factors"""
    base_score = 75
    
    # Load crime data
    try:
        crime_data_path = os.path.join('data', 'crime_data.csv')
        if os.path.exists(crime_data_path):
            crime_df = pd.read_csv(crime_data_path)
            
            # Find nearby crime incidents (within 0.01 degrees ~ 1km)
            nearby_crimes = crime_df[
                (abs(crime_df['latitude'] - lat) < 0.01) & 
                (abs(crime_df['longitude'] - lng) < 0.01)
            ]
            
            if not nearby_crimes.empty:
                high_risk_count = len(nearby_crimes[nearby_crimes['risk_level'] == 'high'])
                moderate_risk_count = len(nearby_crimes[nearby_crimes['risk_level'] == 'moderate'])
                
                # Deduct points based on nearby crimes
                base_score -= (high_risk_count * 15) - (moderate_risk_count * 8)
                
                # Time-based adjustments
                if time_of_day in ['night', 'evening']:
                    base_score -= 10
    except:
        pass
    
    # Crowd density simulation
    crowd_density = random.choice(['low', 'medium', 'high'])
    if crowd_density == 'high':
        base_score += 10
    elif crowd_density == 'low':
        base_score -= 15
    
    # Traffic conditions
    traffic = random.choice(['light', 'moderate', 'heavy'])
    if traffic == 'heavy':
        base_score += 5
    elif traffic == 'light':
        base_score -= 10
    
    return max(0, min(100, base_score))

def get_risk_level(score):
    """Convert safety score to risk level"""
    if score >= 70:
        return 'Safe', 'green'
    elif score >= 40:
        return 'Moderate Risk', 'yellow'
    else:
        return 'High Risk', 'red'

def predict_risk(lat, lng, time_of_day='day'):
    """Use ML model to predict risk level"""
    if safety_model is None:
        return calculate_safety_score(lat, lng, time_of_day)
    
    try:
        # Prepare features
        hour = datetime.now().hour
        
        # Mock features for prediction
        features = np.array([[
            lat, lng,  # coordinates
            0,  # crime_type_encoded (mock)
            hour,  # hour
            1,  # crowd_density_encoded (mock)
            1   # traffic_condition_encoded (mock)
        ]])
        
        # Predict
        prediction = safety_model.predict(features)[0]
        
        # Convert prediction to safety score
        if prediction == 0:  # low risk
            return random.randint(70, 100)
        elif prediction == 1:  # moderate risk
            return random.randint(40, 69)
        else:  # high risk
            return random.randint(0, 39)
    except:
        return calculate_safety_score(lat, lng, time_of_day)

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return render_template('signup.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists')
            return render_template('signup.html')
        
        new_user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password)
        )
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Account created successfully! Please login.')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/map')
@login_required
def map_view():
    return render_template('map.html')

@app.route('/calculate_route', methods=['POST'])
@login_required
def calculate_route():
    data = request.get_json()
    source = data.get('source')
    destination = data.get('destination')
    
    # Mock route calculation with safety scores
    routes = []
    
    # Generate 3 mock routes
    for i in range(3):
        # Mock waypoints between source and destination
        waypoints = []
        num_points = 5
        for j in range(num_points):
            lat = source['lat'] + (destination['lat'] - source['lat']) * (j / num_points) + random.uniform(-0.01, 0.01)
            lng = source['lng'] + (destination['lng'] - source['lng']) * (j / num_points) + random.uniform(-0.01, 0.01)
            waypoints.append({'lat': lat, 'lng': lng})
        
        # Calculate safety score for route
        route_scores = []
        for point in waypoints:
            score = predict_risk(point['lat'], point['lng'])
            route_scores.append(score)
        
        avg_score = sum(route_scores) / len(route_scores)
        risk_level, color = get_risk_level(avg_score)
        
        routes.append({
            'id': i + 1,
            'waypoints': waypoints,
            'safety_score': round(avg_score, 1),
            'risk_level': risk_level,
            'color': color,
            'distance': round(random.uniform(5, 15), 1),
            'duration': round(random.uniform(15, 45), 0)
        })
    
    # Sort by safety score (highest first)
    routes.sort(key=lambda x: x['safety_score'], reverse=True)
    
    return jsonify({'routes': routes})

@app.route('/emergency_alert', methods=['POST'])
@login_required
def emergency_alert():
    data = request.get_json()
    latitude = data.get('latitude')
    longitude = data.get('longitude')
    alert_type = data.get('type', 'manual')
    
    # Log emergency
    emergency = EmergencyLog(
        user_id=current_user.id,
        latitude=latitude,
        longitude=longitude,
        alert_type=alert_type
    )
    
    db.session.add(emergency)
    db.session.commit()
    
    # Simulate sending SMS (mock)
    contacts = []
    if current_user.emergency_contacts:
        try:
            contacts = json.loads(current_user.emergency_contacts)
        except:
            contacts = []
    
    # Mock SMS sending
    for contact in contacts:
        print(f"Emergency SMS sent to {contact}: Help needed! Location: {latitude}, {longitude}")
    
    return jsonify({
        'status': 'success',
        'message': 'Emergency alert sent to your contacts',
        'emergency_id': emergency.id
    })

@app.route('/update_location', methods=['POST'])
@login_required
def update_location():
    data = request.get_json()
    latitude = data.get('latitude')
    longitude = data.get('longitude')
    
    # In a real app, this would update user's live location
    # For now, just return success
    return jsonify({'status': 'success'})

@app.route('/admin')
@login_required
def admin():
    if current_user.username != 'admin':
        flash('Access denied')
        return redirect(url_for('dashboard'))
    
    # Get statistics
    total_users = User.query.count()
    total_emergencies = EmergencyLog.query.count()
    recent_emergencies = EmergencyLog.query.order_by(EmergencyLog.timestamp.desc()).limit(10).all()
    
    return render_template('admin.html', 
                         total_users=total_users,
                         total_emergencies=total_emergencies,
                         recent_emergencies=recent_emergencies)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Create admin user if not exists
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@safety.com',
                password_hash=generate_password_hash('admin123')
            )
            db.session.add(admin_user)
            db.session.commit()
    
    app.run(debug=True, port=5000)