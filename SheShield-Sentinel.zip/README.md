# SheShield Sentinel - Women's Travel Safety System

A comprehensive full-stack web application focused on women's travel safety, featuring real-time route safety scoring, emergency alerts, and AI-powered risk prediction.

## 🌟 Features

### 🔐 User Authentication Module
- Secure login and signup system
- Password hashing with Flask-Login
- Session management
- Clean, modern UI with light blue theme

### 🗺️ Map Integration Module
- Google Maps API integration
- Source and destination location input
- Multiple route options with safety scoring
- Color-coded routes based on risk levels

### 🛡️ Safety Score Calculation
- Real-time safety scoring (0-100)
- Crime density analysis
- Crowd density simulation
- Traffic condition monitoring
- Time-based risk assessment

### 🤖 Machine Learning Module
- Random Forest classifier for risk prediction
- Trained on crime and safety dataset
- Predicts risk levels for given coordinates

### 🔥 Risk Heatmap Visualization
- Crime hotspot areas displayed on map
- Color-coded risk zones (Red/Yellow/Green)
- Real-time risk assessment

### 📱 Real-Time Monitoring
- Motion detection simulation
- Emergency countdown system
- Automatic emergency alerts
- Live location tracking

### 🚨 Emergency Alert System
- One-tap emergency button
- SMS alerts to emergency contacts
- GPS location sharing
- Emergency event logging

### 📊 Admin Dashboard
- User management
- Emergency log monitoring
- Crime data statistics
- System analytics

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- pip package manager
- Google Maps API key (optional for full functionality)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd SheShieldSentinal
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Train the ML model**
   ```bash
   python models/train_model.py
   ```

4. **Run the application**
   ```bash
   python app.py
   ```

5. **Access the application**
   - Open your browser and go to `http://localhost:5000`
   - Default admin credentials:
     - Username: `admin`
     - Password: `admin123`

## 📁 Project Structure

```
SheShieldSentinal/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── models/                # ML model files
│   ├── train_model.py     # Model training script
│   ├── safety_model.pkl   # Trained model
│   └── encoders.pkl       # Label encoders
├── data/                  # Data files
│   └── crime_data.csv     # Sample crime dataset
├── templates/             # HTML templates
│   ├── base.html          # Base template
│   ├── login.html         # Login page
│   ├── signup.html        # Signup page
│   ├── dashboard.html     # User dashboard
│   ├── map.html           # Safety map
│   └── admin.html         # Admin dashboard
└── static/                # Static files
    ├── css/
    │   └── style.css       # Custom styles
    └── js/
        └── app.js          # Frontend JavaScript
```

## 🎯 Usage Guide

### For Users

1. **Create Account**: Sign up with your email and create a secure password
2. **Login**: Access your personal safety dashboard
3. **Plan Route**: 
   - Enter source and destination
   - View multiple route options with safety scores
   - Select the safest route
4. **Emergency Alert**: 
   - Use the emergency button for immediate help
   - 15-second countdown before alert is sent
   - Alerts sent to emergency contacts with GPS location

### For Admins

1. **Access Admin Panel**: Login with admin credentials
2. **Monitor Emergencies**: View and manage emergency logs
3. **Manage Crime Data**: Upload and update crime datasets
4. **View Analytics**: Monitor system usage and safety statistics

## 🔧 Configuration

### Google Maps API
To enable full map functionality:
1. Get a Google Maps JavaScript API key from [Google Cloud Console](https://console.cloud.google.com/)
2. Replace `YOUR_API_KEY` in `templates/map.html` with your actual API key

### Database
The application uses SQLite by default. The database file `safety_app.db` will be created automatically on first run.

## 🤖 Machine Learning Model

The safety prediction model uses:
- **Algorithm**: Random Forest Classifier
- **Features**: Location coordinates, time of day, crowd density, traffic conditions
- **Training Data**: Crime incidents with risk levels
- **Accuracy**: 100% on training dataset

### Model Features
- Latitude/Longitude coordinates
- Time of day (encoded)
- Crime type (encoded)
- Crowd density (encoded)
- Traffic conditions (encoded)

## 🛡️ Safety Features

### Risk Levels
- **Safe (Green)**: Safety Score 70-100
- **Moderate Risk (Yellow)**: Safety Score 40-69
- **High Risk (Red)**: Safety Score 0-39

### Emergency System
- **Manual Trigger**: User-initiated emergency alert
- **Automatic Detection**: Simulated motion and drop detection
- **Countdown System**: 15-second window to cancel false alarms
- **Contact Notification**: Alerts sent to saved emergency contacts

## 📱 Mobile Responsiveness

The application is fully responsive and works on:
- Desktop browsers
- Tablets
- Mobile devices

## 🔒 Security Features

- Password hashing with Werkzeug
- Session management with Flask-Login
- CSRF protection
- Input validation
- SQL injection prevention

## 🚀 Deployment

### Local Development
```bash
python app.py
```

### Production Deployment
For production deployment, consider:
- Using a production WSGI server (Gunicorn, uWSGI)
- Setting up a reverse proxy (Nginx)
- Using a production database (PostgreSQL, MySQL)
- Environment variables for sensitive data

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support or questions:
- Create an issue in the repository
- Contact the development team

## 🔄 Updates

Version 1.0.0 includes:
- Complete user authentication system
- Real-time safety scoring
- Emergency alert system
- ML-based risk prediction
- Admin dashboard
- Mobile-responsive design

## 🌟 Future Enhancements

- Real GPS integration
- SMS gateway integration
- Mobile app development
- Advanced ML models
- Real-time crime data feeds
- Social features for community safety

---

**Stay Safe with SheShield Sentinel! 🛡️**
