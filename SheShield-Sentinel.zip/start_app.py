#!/usr/bin/env python3
"""
SheShield Sentinel - Startup Script
Ensures all dependencies are available and starts the application
"""

import sys
import os
import subprocess
import importlib

def check_dependency(package_name):
    """Check if a Python package is installed"""
    try:
        importlib.import_module(package_name)
        return True
    except ImportError:
        return False

def install_missing_dependencies():
    """Install missing dependencies"""
    required_packages = [
        'flask',
        'flask_sqlalchemy', 
        'flask_login',
        'werkzeug',
        'pandas',
        'numpy',
        'joblib'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        if not check_dependency(package):
            missing_packages.append(package)
    
    if missing_packages:
        print(f"Installing missing packages: {', '.join(missing_packages)}")
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install'] + missing_packages)
            print("✅ Dependencies installed successfully!")
        except subprocess.CalledProcessError:
            print("❌ Failed to install dependencies. Please install manually:")
            print(f"pip install {' '.join(missing_packages)}")
            return False
    
    return True

def check_files():
    """Check if required files exist"""
    required_files = [
        'app.py',
        'templates/base.html',
        'templates/login.html',
        'templates/dashboard.html',
        'templates/map.html',
        'templates/admin.html',
        'static/css/style.css',
        'static/js/app.js',
        'data/crime_data.csv'
    ]
    
    missing_files = []
    
    for file_path in required_files:
        if not os.path.exists(file_path):
            missing_files.append(file_path)
    
    if missing_files:
        print("❌ Missing required files:")
        for file_path in missing_files:
            print(f"   - {file_path}")
        return False
    
    print("✅ All required files present!")
    return True

def main():
    """Main startup function"""
    print("🛡️  SheShield Sentinel - Starting Up...")
    print("=" * 50)
    
    # Check files
    if not check_files():
        print("\n❌ Please ensure all required files are present.")
        return
    
    # Check and install dependencies
    if not install_missing_dependencies():
        print("\n❌ Dependency installation failed.")
        return
    
    print("\n🚀 Starting SheShield Sentinel...")
    print("=" * 50)
    print("📍 Application will be available at: http://localhost:5000")
    print("👤 Admin Login: username='admin', password='admin123'")
    print("🛑 Press Ctrl+C to stop the server")
    print("=" * 50)
    
    try:
        # Import and run the Flask app
        from app import app
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\n🛑 SheShield Sentinel stopped by user")
    except Exception as e:
        print(f"\n❌ Error starting application: {e}")
        print("Please check the error message above and try again.")

if __name__ == "__main__":
    main()
