import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import joblib
import os

def train_safety_model():
    # Load crime data
    data_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'crime_data.csv')
    df = pd.read_csv(data_path)
    
    # Feature engineering
    # Convert time_of_day to hour (mock conversion)
    time_mapping = {'morning': 9, 'afternoon': 14, 'evening': 18, 'night': 22}
    df['hour'] = df['time_of_day'].map(time_mapping)
    
    # Encode categorical variables
    le_crime = LabelEncoder()
    le_risk = LabelEncoder()
    le_crowd = LabelEncoder()
    le_traffic = LabelEncoder()
    
    df['crime_type_encoded'] = le_crime.fit_transform(df['crime_type'])
    df['risk_level_encoded'] = le_risk.fit_transform(df['risk_level'])
    df['crowd_density_encoded'] = le_crowd.fit_transform(df['crowd_density'])
    df['traffic_condition_encoded'] = le_traffic.fit_transform(df['traffic_condition'])
    
    # Features for training
    features = ['latitude', 'longitude', 'crime_type_encoded', 'hour', 
                'crowd_density_encoded', 'traffic_condition_encoded']
    X = df[features]
    y = df['risk_level_encoded']
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train Random Forest model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Save model and encoders
    model_path = os.path.join(os.path.dirname(__file__), 'safety_model.pkl')
    joblib.dump(model, model_path)
    
    encoders_path = os.path.join(os.path.dirname(__file__), 'encoders.pkl')
    joblib.dump({
        'crime_type': le_crime,
        'risk_level': le_risk,
        'crowd_density': le_crowd,
        'traffic_condition': le_traffic
    }, encoders_path)
    
    print(f"Model trained and saved to {model_path}")
    print(f"Accuracy: {model.score(X_test, y_test):.2f}")
    
    return model, le_risk

if __name__ == "__main__":
    train_safety_model()
