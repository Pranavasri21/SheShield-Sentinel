// SheShield Sentinel - Main JavaScript Application

class SheShieldApp {
    constructor() {
        this.currentUser = null;
        this.currentLocation = null;
        this.watchId = null;
        this.emergencyCountdown = null;
        this.selectedRoute = null;
        this.isMonitoring = false;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.checkAuthStatus();
        this.initializeLocationTracking();
        this.setupRealTimeMonitoring();
    }

    setupEventListeners() {
        // Global error handling
        window.addEventListener('error', (e) => {
            console.error('Application error:', e);
            this.showNotification('An error occurred. Please try again.', 'danger');
        });

        // Online/offline detection
        window.addEventListener('online', () => {
            this.showNotification('Connection restored', 'success');
        });

        window.addEventListener('offline', () => {
            this.showNotification('Connection lost. Some features may be unavailable.', 'warning');
        });
    }

    checkAuthStatus() {
        // Check if user is authenticated
        fetch('/api/user/status')
            .then(response => response.json())
            .then(data => {
                if (data.authenticated) {
                    this.currentUser = data.user;
                    this.setupUserSpecificFeatures();
                }
            })
            .catch(error => {
                console.log('Auth check failed:', error);
            });
    }

    setupUserSpecificFeatures() {
        // Setup features that require authentication
        this.loadEmergencyContacts();
        this.initializeSafetyMonitoring();
    }

    initializeLocationTracking() {
        if (navigator.geolocation) {
            // Get initial location
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.currentLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    this.onLocationUpdate(this.currentLocation);
                },
                (error) => {
                    console.log('Location access denied:', error);
                    this.showNotification('Location access is recommended for better safety features', 'warning');
                }
            );

            // Watch position changes
            this.watchId = navigator.geolocation.watchPosition(
                (position) => {
                    const newLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    
                    // Only update if location changed significantly
                    if (!this.currentLocation || 
                        this.calculateDistance(this.currentLocation, newLocation) > 0.001) {
                        this.currentLocation = newLocation;
                        this.onLocationUpdate(newLocation);
                    }
                },
                (error) => {
                    console.log('Location tracking error:', error);
                },
                {
                    enableHighAccuracy: true,
                    maximumAge: 30000,
                    timeout: 27000
                }
            );
        }
    }

    onLocationUpdate(location) {
        // Update server with new location
        this.updateServerLocation(location);
        
        // Check for safety alerts
        this.checkLocationSafety(location);
        
        // Update UI elements
        this.updateLocationDisplay(location);
    }

    updateServerLocation(location) {
        fetch('/update_location', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(location)
        })
        .catch(error => {
            console.log('Failed to update server location:', error);
        });
    }

    checkLocationSafety(location) {
        // Simulate safety check
        const safetyScore = Math.floor(Math.random() * 30) + 70;
        
        if (safetyScore < 40 && this.isMonitoring) {
            this.showNotification('Warning: You are entering a high-risk area', 'warning');
        }
    }

    updateLocationDisplay(location) {
        // Update location display elements
        const locationElements = document.querySelectorAll('.current-location');
        locationElements.forEach(element => {
            element.textContent = `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`;
        });
    }

    setupRealTimeMonitoring() {
        const monitoringToggle = document.getElementById('liveMonitoring');
        if (monitoringToggle) {
            monitoringToggle.addEventListener('change', (e) => {
                this.isMonitoring = e.target.checked;
                if (this.isMonitoring) {
                    this.startMonitoring();
                } else {
                    this.stopMonitoring();
                }
            });
        }
    }

    startMonitoring() {
        this.showNotification('Real-time monitoring activated', 'success');
        // Start additional monitoring features
        this.startMotionDetection();
        this.startPeriodicSafetyChecks();
    }

    stopMonitoring() {
        this.showNotification('Real-time monitoring deactivated', 'info');
        // Stop monitoring features
        this.stopMotionDetection();
        this.stopPeriodicSafetyChecks();
    }

    startMotionDetection() {
        // Simulate motion detection
        this.motionDetectionInterval = setInterval(() => {
            // In a real app, this would use device motion APIs
            const abnormalMotion = Math.random() < 0.05; // 5% chance
            
            if (abnormalMotion && this.isMonitoring) {
                this.detectAbnormalMovement();
            }
        }, 10000); // Check every 10 seconds
    }

    stopMotionDetection() {
        if (this.motionDetectionInterval) {
            clearInterval(this.motionDetectionInterval);
        }
    }

    detectAbnormalMovement() {
        this.showNotification('Abnormal movement detected! Emergency countdown started.', 'danger');
        this.startEmergencyCountdown();
    }

    startPeriodicSafetyChecks() {
        this.safetyCheckInterval = setInterval(() => {
            if (this.currentLocation) {
                this.checkLocationSafety(this.currentLocation);
            }
        }, 60000); // Check every minute
    }

    stopPeriodicSafetyChecks() {
        if (this.safetyCheckInterval) {
            clearInterval(this.safetyCheckInterval);
        }
    }

    triggerEmergencyAlert(type = 'manual') {
        this.startEmergencyCountdown(type);
    }

    startEmergencyCountdown(type = 'manual') {
        let countdown = 15;
        
        // Show emergency modal
        const modal = document.getElementById('emergencyModal');
        if (modal) {
            const bsModal = new bootstrap.Modal(modal);
            bsModal.show();
            
            const countdownElement = document.getElementById('countdown');
            if (countdownElement) {
                this.emergencyCountdown = setInterval(() => {
                    countdown--;
                    countdownElement.textContent = countdown;
                    
                    if (countdown <= 0) {
                        clearInterval(this.emergencyCountdown);
                        this.sendEmergencyAlert(type);
                        bsModal.hide();
                    }
                }, 1000);
            }
        }
    }

    cancelEmergencyAlert() {
        if (this.emergencyCountdown) {
            clearInterval(this.emergencyCountdown);
            this.showNotification('Emergency alert cancelled', 'info');
        }
        
        const modal = document.getElementById('emergencyModal');
        if (modal) {
            const bsModal = bootstrap.Modal.getInstance(modal);
            if (bsModal) {
                bsModal.hide();
            }
        }
    }

    sendEmergencyAlert(type) {
        const location = this.currentLocation || { lat: 28.6139, lng: 77.2090 };
        
        fetch('/emergency_alert', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                latitude: location.lat,
                longitude: location.lng,
                type: type
            })
        })
        .then(response => response.json())
        .then(data => {
            this.showNotification('Emergency alert sent successfully!', 'success');
            this.logEmergencyEvent(type, location);
        })
        .catch(error => {
            console.error('Error sending emergency alert:', error);
            this.showNotification('Failed to send emergency alert', 'danger');
        });
    }

    logEmergencyEvent(type, location) {
        // Log emergency for analytics
        const event = {
            type: type,
            location: location,
            timestamp: new Date().toISOString(),
            userId: this.currentUser ? this.currentUser.id : null
        };
        
        console.log('Emergency event logged:', event);
    }

    loadEmergencyContacts() {
        // Load emergency contacts from server
        fetch('/api/emergency_contacts')
            .then(response => response.json())
            .then(contacts => {
                this.displayEmergencyContacts(contacts);
            })
            .catch(error => {
                console.log('Failed to load emergency contacts:', error);
            });
    }

    displayEmergencyContacts(contacts) {
        const container = document.getElementById('emergencyContactsList');
        if (container && contacts) {
            container.innerHTML = contacts.map(contact => `
                <div class="contact-item d-flex justify-content-between align-items-center mb-2">
                    <span><i class="fas fa-phone me-2"></i>${contact.name}</span>
                    <span class="badge bg-success">Active</span>
                </div>
            `).join('');
        }
    }

    calculateDistance(point1, point2) {
        // Calculate distance between two points (in degrees)
        return Math.sqrt(
            Math.pow(point1.lat - point2.lat, 2) + 
            Math.pow(point1.lng - point2.lng, 2)
        );
    }

    showNotification(message, type = 'info', duration = 5000) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-${this.getNotificationIcon(type)} me-2"></i>
                <span>${message}</span>
                <button type="button" class="btn-close btn-close-white ms-auto" onclick="this.parentElement.parentElement.remove()"></button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after duration
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, duration);
    }

    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            warning: 'exclamation-triangle',
            danger: 'exclamation-circle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }

    // Route planning methods
    calculateRoute(source, destination) {
        this.showLoading();
        
        fetch('/calculate_route', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                source: source,
                destination: destination
            })
        })
        .then(response => response.json())
        .then(data => {
            this.hideLoading();
            this.displayRoutes(data.routes);
        })
        .catch(error => {
            this.hideLoading();
            console.error('Error calculating route:', error);
            this.showNotification('Failed to calculate routes', 'danger');
        });
    }

    displayRoutes(routes) {
        const routeList = document.getElementById('routeList');
        if (routeList) {
            routeList.innerHTML = routes.map((route, index) => `
                <div class="route-card card mb-2" onclick="app.selectRoute(${index})">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">Route ${route.id}</h6>
                                <div class="d-flex align-items-center mb-2">
                                    <span class="risk-badge risk-${route.color === 'green' ? 'safe' : 
                                                           route.color === 'yellow' ? 'moderate' : 'high'}">
                                        ${route.risk_level}
                                    </span>
                                    <small class="text-muted ms-2">Safety Score: ${route.safety_score}/100</small>
                                </div>
                                <small class="text-muted">
                                    <i class="fas fa-route me-1"></i>${route.distance} km | 
                                    <i class="fas fa-clock me-1"></i>${route.duration} min
                                </small>
                            </div>
                            <button class="btn btn-sm btn-primary">
                                Select
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        }
        
        document.getElementById('routeOptions').style.display = 'block';
    }

    selectRoute(index) {
        this.selectedRoute = index;
        
        // Update UI to show selected route
        document.querySelectorAll('.route-card').forEach((card, i) => {
            if (i === index) {
                card.classList.add('selected');
            } else {
                card.classList.remove('selected');
            }
        });
        
        this.showNotification(`Route ${index + 1} selected`, 'success');
    }

    showLoading() {
        const spinner = document.querySelector('.loading-spinner');
        if (spinner) {
            spinner.style.display = 'block';
        }
    }

    hideLoading() {
        const spinner = document.querySelector('.loading-spinner');
        if (spinner) {
            spinner.style.display = 'none';
        }
    }

    // Utility methods
    formatTime(date) {
        return date.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }

    formatDate(date) {
        return date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
    }

    // Cleanup
    destroy() {
        if (this.watchId) {
            navigator.geolocation.clearWatch(this.watchId);
        }
        
        if (this.emergencyCountdown) {
            clearInterval(this.emergencyCountdown);
        }
        
        this.stopMotionDetection();
        this.stopPeriodicSafetyChecks();
    }
}

// Initialize the application
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new SheShieldApp();
    
    // Make app globally available for inline event handlers
    window.app = app;
    
    // Setup global emergency functions
    window.triggerEmergency = () => app.triggerEmergencyAlert();
    window.cancelEmergency = () => app.cancelEmergencyAlert();
    window.sendEmergencyNow = () => {
        app.cancelEmergencyAlert();
        app.sendEmergencyAlert('manual');
    };
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (app) {
        app.destroy();
    }
});
